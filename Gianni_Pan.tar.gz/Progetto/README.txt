------------------- PROGETTO BIBLIO | LABORATORIO II 2022/2023 -----------------------
MATRICOLA: 615945
NOME E COGNOME: GIANNI PAN
-------------- ISTRUZIONI PER LA COMPILAZIONE/ESECUZIONE DEL CODICE ------------------
- Aprire il terminale e navigare dentro la directory contenente lo zip.
- Estrarre lo zip tramite comando "tar -xzvf Gianni_Pan.tar.gz".
- Lo zip contiene una cartella chiamata Progetto.
- Eseguire il comando cd Progetto per spostarsi dentro la directory
- All'interno della cartella eseguire:
  - "make all" per creare tutti gli eseguibili.
  - "make test" per eseguire lo script per avviare 5 server e 40 client.
  - "make clean" per pulire la directory dai file generati.
--------------------------------------------------------------------------------------
